package com.example.labtask;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage primaryStage) {

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(9);
        grid.setVgap(8);

        Label nameLabel = new Label("Full Name:");
        TextField nameField = new TextField();

        Label idLabel = new Label("ID:");
        TextField idField = new TextField();

        Label genderLabel = new Label("Gender:");
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton maleButton = new RadioButton("Male");
        RadioButton femaleButton = new RadioButton("Female");
        maleButton.setToggleGroup(genderGroup);
        femaleButton.setToggleGroup(genderGroup);

        Label provinceLabel = new Label("Province:");
        ComboBox<String> provinceDropdown = new ComboBox<>();
        provinceDropdown.getItems().addAll("Punjab", "Sindh", "K.P.K", "Balochistan");
        provinceDropdown.setPromptText("Select Province");

        Label dobLabel = new Label("DOB:");
        DatePicker dobPicker = new DatePicker();

        Button newButton = new Button("New");
        Button deleteButton = new Button("Delete");
        Button restoreButton = new Button("Restore");
        Button criteriaButton = new Button("Criteria");
        Button findButton = new Button("Find");
        Button closeButton = new Button("Close");

        VBox buttonBox = new VBox(10, newButton, deleteButton, restoreButton, findButton, criteriaButton, closeButton);

        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(idLabel, 0, 1);
        grid.add(idField, 1, 1);
        grid.add(genderLabel, 0, 2);
        grid.add(new HBox(10, maleButton, femaleButton), 1, 2);
        grid.add(provinceLabel, 0, 3);
        grid.add(provinceDropdown, 1, 3);
        grid.add(dobLabel, 0, 4);
        grid.add(dobPicker, 1, 4);
        grid.add(buttonBox, 2, 0, 1, 6);


        newButton.setOnAction(e -> {
            String name = nameField.getText();
            String id = idField.getText();
            String gender = maleButton.isSelected() ? "Male" : (femaleButton.isSelected() ? "Female" : "");
            String province = provinceDropdown.getValue();
            String dob = dobPicker.getValue() != null ? dobPicker.getValue().toString() : "";

            if (name.isEmpty() || id.isEmpty() || gender.isEmpty() || province == null || dob.isEmpty()) {
                System.out.println("Error: All fields are required!");
                return;
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(id + ".txt"))) {
                writer.write("Full Name: " + name + "\n");
                writer.write("ID: " + id + "\n");
                writer.write("Gender: " + gender + "\n");
                writer.write("Home Province: " + province + "\n");
                writer.write("DOB: " + dob + "\n");


                showAlert(Alert.AlertType.INFORMATION, "Success", "Data saved successfully!");
            } catch (IOException ex) {
                System.out.println("Error: Failed to save data!");
            }
        });


        findButton.setOnAction(e -> {
            Stage findStage = new Stage();
            GridPane findGrid = new GridPane();
            findGrid.setPadding(new Insets(20));
            findGrid.setHgap(5);
            findGrid.setVgap(15);

            Label findIdLabel = new Label("Enter ID:");
            TextField findIdField = new TextField();
            Button searchButton = new Button("Search");

            findGrid.add(findIdLabel, 0, 0);
            findGrid.add(findIdField, 1, 0);
            findGrid.add(searchButton, 1, 1);

            searchButton.setOnAction(event -> {
                String searchId = findIdField.getText();
                if (searchId.isEmpty()) {
                    System.out.println("Error: ID is required!");
                    return;
                }

                File file = new File(searchId + ".txt");
                if (file.exists()) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "ID Found!");
                } else {
                    System.out.println("ID Not Found!");
                }
            });

            Scene findScene = new Scene(findGrid, 300, 150);
            findStage.setScene(findScene);
            findStage.setTitle("Find Record");
            findStage.show();
        });


        closeButton.setOnAction(e -> primaryStage.close());

        Scene scene = new Scene(grid, 700, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Data Entry Form");
        primaryStage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
