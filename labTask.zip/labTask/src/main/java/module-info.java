module com.example.labtask {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.labtask to javafx.fxml;
    exports com.example.labtask;
}